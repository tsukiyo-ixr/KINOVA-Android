# KINOVA MVP: no custom ProGuard rules required yet.
