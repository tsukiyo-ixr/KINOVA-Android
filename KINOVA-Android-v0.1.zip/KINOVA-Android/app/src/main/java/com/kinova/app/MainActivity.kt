package com.kinova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF090A10)
private val Panel = Color(0xFF151722)
private val Violet = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9A9BAB)

data class Media(
    val title: String,
    val category: String,
    val year: String,
    val description: String,
    val emoji: String,
    val accent: Color
)

private val catalog = listOf(
    Media("The Silent Horizon", "Anime", "2025", "A mysterious signal changes the lives of three students.", "🌌", Color(0xFF44316E)),
    Media("Neon District", "Series", "2024", "A city-wide mystery unfolds after an unexplained blackout.", "🌃", Color(0xFF244B63)),
    Media("Beyond the Orbit", "Movie", "2025", "A small crew sets out on a journey beyond known space.", "🚀", Color(0xFF59402F)),
    Media("Crimson Ronin", "Anime", "2024", "A wandering swordsman searches for the truth behind an old legend.", "⚔️", Color(0xFF702F42)),
    Media("The Last Archive", "Series", "2023", "An archivist discovers memories that should not exist.", "📼", Color(0xFF31564C)),
    Media("Moonlit Letters", "Anime", "2025", "Two distant friends connect through letters carried by the wind.", "🌙", Color(0xFF3D4777))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 16)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 16)
        setContent { KinovaApp() }
    }
}

@Composable
private fun KinovaApp() {
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Media?>(null) }
    var showPlayer by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = Panel,
            primary = Violet,
            secondary = Color(0xFF6DD6D0),
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            when {
                showPlayer -> PlayerScreen(onBack = { showPlayer = false })
                selected != null -> DetailScreen(
                    media = selected!!,
                    onBack = { selected = null },
                    onPlay = { showPlayer = true }
                )
                else -> Scaffold(
                    containerColor = Ink,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF11131C)) {
                            val destinations = listOf(
                                "Home" to Icons.Default.Home,
                                "Anime" to Icons.Default.AutoAwesome,
                                "Movies" to Icons.Default.Movie,
                                "Series" to Icons.Default.Tv,
                                "Search" to Icons.Default.Search
                            )
                            destinations.forEach { (name, icon) ->
                                NavigationBarItem(
                                    selected = tab == name,
                                    onClick = { tab = name },
                                    icon = { Icon(icon, contentDescription = name) },
                                    label = { Text(name, fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Violet,
                                        selectedTextColor = Violet,
                                        indicatorColor = Violet.copy(alpha = 0.15f),
                                        unselectedIconColor = Muted,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    when (tab) {
                        "Search" -> SearchScreen(
                            modifier = Modifier.padding(padding),
                            onSelect = { selected = it }
                        )
                        else -> CatalogScreen(
                            tab = tab,
                            modifier = Modifier.padding(padding),
                            onSelect = { selected = it }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CatalogScreen(tab: String, modifier: Modifier, onSelect: (Media) -> Unit) {
    val visible = when (tab) {
        "Anime", "Movies", "Series" -> catalog.filter { it.category == tab.removeSuffix("s") || it.category == tab }
        else -> catalog
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 22.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("KINOVA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("YOUR WORLD OF STORIES", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                IconButton(onClick = {}) {
                    Icon(Icons.Default.AccountCircle, contentDescription = "Profile", tint = Violet, modifier = Modifier.size(29.dp))
                }
            }
        }
        if (tab == "Home") {
            item {
                FeaturedCard(media = catalog[0], onClick = { onSelect(catalog[0]) })
            }
            item { SectionTitle("Trending now", "HOT THIS WEEK") }
            item { MediaRail(catalog, onSelect) }
            item { SectionTitle("Anime universe", "EXPLORE ANIME") }
            item { MediaRail(catalog.filter { it.category == "Anime" }, onSelect) }
            item { SectionTitle("Movies & series", "YOUR NEXT WATCH") }
            item { MediaRail(catalog.filter { it.category != "Anime" }, onSelect) }
        } else {
            item {
                Text(tab, fontSize = 29.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 10.dp, bottom = 14.dp))
            }
            item { MediaRail(visible, onSelect) }
            items(visible) { media ->
                MediaListRow(media, onSelect)
            }
        }
    }
}

@Composable
private fun FeaturedCard(media: Media, onClick: () -> Unit) {
    Column(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            .background(Brush.linearGradient(listOf(media.accent, Color(0xFF171827), Ink)), RoundedCornerShape(25.dp))
            .clickable { onClick() }.padding(22.dp)
    ) {
        Text("KINOVA ORIGINAL • FEATURED", color = Color.White.copy(alpha = .7f), fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(62.dp))
        Text(media.emoji, fontSize = 46.sp)
        Text(media.title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        Text("${media.category}  •  ${media.year}", color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
        Spacer(Modifier.height(13.dp))
        Text(media.description, color = Color.White.copy(alpha = .85f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Ink)
            Text("  EXPLORE", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 25.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Violet, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun MediaRail(items: List<Media>, onSelect: (Media) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(items) { media ->
            Column(Modifier.width(132.dp).clickable { onSelect(media) }) {
                Box(
                    Modifier.fillMaxWidth().height(174.dp)
                        .background(Brush.linearGradient(listOf(media.accent, Panel)), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(media.emoji, fontSize = 47.sp)
                    Text(media.category.uppercase(), color = Color.White.copy(alpha = .75f), fontSize = 8.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(10.dp), letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(media.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(media.year, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun MediaListRow(media: Media, onSelect: (Media) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onSelect(media) }.padding(horizontal = 20.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(58.dp).background(media.accent, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(media.emoji, fontSize = 26.sp)
        }
        Column(Modifier.weight(1f).padding(start = 13.dp)) {
            Text(media.title, fontWeight = FontWeight.SemiBold)
            Text("${media.category} • ${media.year}", color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
    }
}

@Composable
private fun SearchScreen(modifier: Modifier, onSelect: (Media) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = catalog.filter { it.title.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true) }
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Discover", fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Text("Find your next favourite story.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search anime, movies, series...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Violet,
                unfocusedBorderColor = Color(0xFF343746),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(results) { MediaListRow(it, onSelect) }
        }
    }
}

@Composable
private fun DetailScreen(media: Media, onBack: () -> Unit, onPlay: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().height(290.dp)
                .background(Brush.verticalGradient(listOf(media.accent, Ink)))
        ) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(10.dp)) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(media.emoji, fontSize = 86.sp, modifier = Modifier.align(Alignment.Center))
            Text("KINOVA", color = Color.White.copy(alpha = .6f), fontSize = 10.sp, letterSpacing = 3.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(20.dp))
        }
        Column(Modifier.padding(22.dp)) {
            Text(media.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("${media.category}  •  ${media.year}  •  Demo catalog", color = Violet, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Text(media.description, color = Muted, fontSize = 14.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(25.dp))
            Button(onClick = onPlay, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Text("  PLAY DEMO", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Text("Playback currently uses a public sample video. Licensed content sources can be connected in a later phase.",
                color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun PlayerScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(
                "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            ))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("KINOVA PLAYER", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                }
            },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        )
        Text("Demo playback", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(18.dp))
        Text("This is a sample video used to verify the player integration. It is not a movie or anime catalog stream.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp))
    }
}
